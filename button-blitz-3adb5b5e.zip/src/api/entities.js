import { base44 } from './base44Client';


export const Game = base44.entities.Game;



// auth sdk:
export const User = base44.auth;